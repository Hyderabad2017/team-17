package ineye.jpmccfg.com.ieyecfg;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by swapn on 16-07-2017.
 */

public class VolunteerActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer);






    }
}
